"""Goldbook local research application."""
